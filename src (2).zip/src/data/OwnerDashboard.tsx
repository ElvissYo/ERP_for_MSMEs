import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';

// ─── KPI Card ─────────────────────────────────────────────────────────────────
function KPICard({
  label,
  value,
  sub,
  icon,
  accent,
}: {
  label: string;
  value: string;
  sub?: string;
  icon: React.ReactNode;
  accent: string;
}) {
  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-5 flex gap-4 items-start">
      <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${accent}`}>
        {icon}
      </div>
      <div className="min-w-0">
        <p className="text-xs text-slate-500 uppercase tracking-wider font-medium mb-1">{label}</p>
        <p className="text-xl font-bold text-slate-900 leading-none">{value}</p>
        {sub && <p className="text-xs text-slate-400 mt-1">{sub}</p>}
      </div>
    </div>
  );
}

// ─── Stock level indicator bar ────────────────────────────────────────────────
function StockBar({ stock, reorder }: { stock: number; reorder: number }) {
  const pct = Math.min((stock / (reorder * 3)) * 100, 100);
  const color = stock === 0 ? 'bg-red-500' : stock < reorder ? 'bg-amber-400' : 'bg-emerald-500';
  return (
    <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
      <div className={`h-full rounded-full transition-all ${color}`} style={{ width: `${pct}%` }} />
    </div>
  );
}

// ─── Main Owner Dashboard ─────────────────────────────────────────────────────
export default function OwnerDashboard() {
  const { transactions, inventory, expenses, approveExpense } = useAppContext();
  const [approvingId, setApprovingId] = useState<string | null>(null);

  const paidTxns = transactions.filter(t => t.payment_status === 'PAID');
  const totalRevenue = paidTxns.reduce((sum, t) => sum + t.subtotal, 0);
  const totalTax = paidTxns.reduce((sum, t) => sum + t.tax_amount, 0);
  const totalPaid = paidTxns.reduce((sum, t) => sum + t.total_amount, 0);
  const lowStockItems = inventory.filter(i => i.stock < i.reorder_point);
  const pendingExpenses = expenses.filter(e => e.approval_status === 'PENDING');
  const approvedExpenses = expenses.filter(e => e.approval_status === 'APPROVED');
  const totalExpense = approvedExpenses.reduce((s, e) => s + e.amount, 0);

  const handleApprove = (id: string) => {
    setApprovingId(id);
    setTimeout(() => {
      approveExpense(id);
      setApprovingId(null);
    }, 500);
  };

  return (
    <div className="space-y-5">
      {/* ── KPI Cards ── */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        <KPICard
          label="Total Pendapatan"
          value={`Rp ${totalRevenue.toLocaleString('id-ID')}`}
          sub={`${paidTxns.length} transaksi terbayar`}
          accent="bg-emerald-100"
          icon={
            <svg className="w-5 h-5 text-emerald-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          }
        />
        <KPICard
          label="Total Pajak PPN"
          value={`Rp ${totalTax.toLocaleString('id-ID')}`}
          sub="11% dari pendapatan"
          accent="bg-sky-100"
          icon={
            <svg className="w-5 h-5 text-sky-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M9 14l6-6m-5.5.5h.01m4.99 5h.01M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16l3.5-2 3.5 2 3.5-2 3.5 2z" />
            </svg>
          }
        />
        <KPICard
          label="Total Penerimaan"
          value={`Rp ${totalPaid.toLocaleString('id-ID')}`}
          sub="Subtotal + PPN"
          accent="bg-violet-100"
          icon={
            <svg className="w-5 h-5 text-violet-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
            </svg>
          }
        />
        <KPICard
          label="Pengeluaran Disetujui"
          value={`Rp ${totalExpense.toLocaleString('id-ID')}`}
          sub={`${approvedExpenses.length} item disetujui`}
          accent="bg-amber-100"
          icon={
            <svg className="w-5 h-5 text-amber-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
            </svg>
          }
        />
      </div>

      {/* ── Bottom panels ── */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
        {/* Low Stock Alert */}
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <svg className="w-4 h-4 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              <h3 className="text-sm font-semibold text-slate-700">Stok Inventory</h3>
            </div>
            {lowStockItems.length > 0 && (
              <span className="bg-amber-50 text-amber-700 border border-amber-200 text-[10px] font-bold px-2 py-0.5 rounded-full">
                {lowStockItems.length} PERLU RESTOCK
              </span>
            )}
          </div>
          <div className="divide-y divide-slate-100">
            {inventory.slice(0, 8).map(item => {
              const isLow = item.stock < item.reorder_point;
              const isEmpty = item.stock === 0;
              return (
                <div key={item.inventory_id} className="px-5 py-3.5 flex items-center gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="text-sm font-medium text-slate-700 truncate">{item.item_name}</p>
                      {isEmpty && (
                        <span className="text-[10px] bg-red-50 text-red-600 border border-red-200 px-1.5 py-0.5 rounded-full font-bold shrink-0">HABIS</span>
                      )}
                      {isLow && !isEmpty && (
                        <span className="text-[10px] bg-amber-50 text-amber-600 border border-amber-200 px-1.5 py-0.5 rounded-full font-bold shrink-0">TIPIS</span>
                      )}
                    </div>
                    <StockBar stock={item.stock} reorder={item.reorder_point} />
                  </div>
                  <div className="text-right shrink-0">
                    <p className={`text-sm font-bold ${isEmpty ? 'text-red-500' : isLow ? 'text-amber-600' : 'text-slate-800'}`}>
                      {item.stock}
                    </p>
                    <p className="text-[10px] text-slate-400">min. {item.reorder_point}</p>
                  </div>
                </div>
              );
            })}
            {inventory.length === 0 && (
              <div className="px-5 py-8 text-center text-sm text-slate-400">
                Tidak ada data inventory
              </div>
            )}
          </div>
        </div>

        {/* Expense Approval */}
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
              </svg>
              <h3 className="text-sm font-semibold text-slate-700">Persetujuan Pengeluaran</h3>
            </div>
            {pendingExpenses.length > 0 && (
              <span className="bg-violet-50 text-violet-700 border border-violet-200 text-[10px] font-bold px-2 py-0.5 rounded-full">
                {pendingExpenses.length} PENDING
              </span>
            )}
          </div>

          <div className="divide-y divide-slate-100">
            {/* Pending list */}
            {pendingExpenses.length === 0 && (
              <div className="px-5 py-8 text-center">
                <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <svg className="w-5 h-5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <p className="text-sm font-medium text-slate-600">Semua pengeluaran telah disetujui</p>
                <p className="text-xs text-slate-400 mt-0.5">Tidak ada item menunggu persetujuan</p>
              </div>
            )}
            {pendingExpenses.map(exp => (
              <div key={exp.expense_id} className="px-5 py-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="text-sm font-semibold text-slate-800 truncate">{exp.expense_name}</p>
                      <span className="text-[10px] bg-orange-50 text-orange-600 border border-orange-200 px-1.5 py-0.5 rounded-full font-bold shrink-0">PENDING</span>
                    </div>
                    <p className="text-xs text-slate-500">
                      {exp.category} · {new Date(exp.expense_date || exp.created_at || '').toLocaleDateString('id-ID')}
                    </p>
                    <p className="text-base font-bold text-slate-900 mt-1.5">Rp {exp.amount.toLocaleString('id-ID')}</p>
                  </div>
                  <button
                    onClick={() => handleApprove(exp.expense_id)}
                    disabled={approvingId === exp.expense_id}
                    className="shrink-0 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-400 text-white text-xs font-bold rounded-xl transition-all duration-150 flex items-center gap-1.5"
                  >
                    {approvingId === exp.expense_id ? (
                      <>
                        <svg className="w-3.5 h-3.5 animate-spin" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                        </svg>
                        Proses...
                      </>
                    ) : (
                      <>
                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                        </svg>
                        Setujui
                      </>
                    )}
                  </button>
                </div>
              </div>
            ))}

            {/* Approved history */}
            {approvedExpenses.slice(0, 3).map(exp => (
              <div key={exp.expense_id} className="px-5 py-3.5 flex items-center gap-3 opacity-60">
                <div className="w-5 h-5 bg-emerald-100 rounded-full flex items-center justify-center shrink-0">
                  <svg className="w-3 h-3 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-slate-600 truncate">{exp.expense_name}</p>
                  <p className="text-[10px] text-slate-400">{exp.category}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-xs font-bold text-slate-600">Rp {exp.amount.toLocaleString('id-ID')}</p>
                  <span className="text-[10px] bg-emerald-50 text-emerald-600 border border-emerald-200 px-1.5 py-0.5 rounded-full font-bold">APPROVED</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Recent Transactions ── */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center gap-2">
          <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
          </svg>
          <h3 className="text-sm font-semibold text-slate-700">Riwayat Transaksi Terakhir</h3>
          <span className="ml-auto text-xs text-slate-400">{transactions.length} total</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 text-xs text-slate-500 uppercase tracking-wider">
                <th className="text-left px-5 py-3 font-medium">ID Transaksi</th>
                <th className="text-left px-5 py-3 font-medium">Tanggal</th>
                <th className="text-left px-5 py-3 font-medium">Metode</th>
                <th className="text-right px-5 py-3 font-medium">Subtotal</th>
                <th className="text-right px-5 py-3 font-medium">Total</th>
                <th className="text-center px-5 py-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {transactions.slice(-10).reverse().map(t => (
                <tr key={t.transaction_id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-5 py-3 font-mono text-xs text-slate-600">{t.transaction_id}</td>
                  <td className="px-5 py-3 text-xs text-slate-500">{new Date(t.transaction_date).toLocaleDateString('id-ID')}</td>
                  <td className="px-5 py-3 text-xs text-slate-600">{t.payment_method}</td>
                  <td className="px-5 py-3 text-right text-xs font-medium text-slate-700">Rp {t.subtotal.toLocaleString('id-ID')}</td>
                  <td className="px-5 py-3 text-right text-xs font-bold text-slate-900">Rp {t.total_amount.toLocaleString('id-ID')}</td>
                  <td className="px-5 py-3 text-center">
                    <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${
                      t.payment_status === 'PAID'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : 'bg-red-50 text-red-600 border border-red-200'
                    }`}>
                      {t.payment_status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}