import React, { useState } from 'react';
import { auditTrail } from '../data/auditTrail';
import { useAppContext } from '../context/AppContext';

// ─── Tab component ────────────────────────────────────────────────────────────
type Tab = 'journal' | 'audit';

function TabButton({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`px-5 py-2.5 text-sm font-semibold border-b-2 transition-all duration-150 ${
        active
          ? 'border-violet-600 text-violet-700'
          : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
      }`}
    >
      {children}
    </button>
  );
}

// ─── Action badge ────────────────────────────────────────────────────────────
const ACTION_COLORS: Record<string, string> = {
  LOGIN:             'bg-sky-50 text-sky-700 border border-sky-200',
  LOGOUT:            'bg-slate-100 text-slate-600 border border-slate-200',
  CREATE_TRANSACTION:'bg-emerald-50 text-emerald-700 border border-emerald-200',
  APPROVE_EXPENSE:   'bg-violet-50 text-violet-700 border border-violet-200',
  DEDUCT_INVENTORY:  'bg-amber-50 text-amber-700 border border-amber-200',
  VIEW_REPORT:       'bg-blue-50 text-blue-700 border border-blue-200',
  default:           'bg-slate-100 text-slate-600 border border-slate-200',
};

function ActionBadge({ action }: { action: string }) {
  const cls = ACTION_COLORS[action] || ACTION_COLORS.default;
  return (
    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${cls} whitespace-nowrap`}>
      {action.replace(/_/g, ' ')}
    </span>
  );
}

// ─── Account type helpers ────────────────────────────────────────────────────
function getAccountType(account: string): 'debit' | 'credit' | 'neutral' {
  if (account.startsWith('1')) return 'debit';   // Asset
  if (account.startsWith('2')) return 'credit';  // Liability
  if (account.startsWith('4')) return 'credit';  // Revenue
  if (account.startsWith('5')) return 'debit';   // Expense
  return 'neutral';
}

// ─── Summary cards at top ────────────────────────────────────────────────────
function SummaryCard({ label, value, sub, cls }: { label: string; value: string | number; sub?: string; cls: string }) {
  return (
    <div className={`rounded-xl p-4 ${cls}`}>
      <p className="text-xs font-medium opacity-70 mb-1 uppercase tracking-wider">{label}</p>
      <p className="text-xl font-bold">{value}</p>
      {sub && <p className="text-xs opacity-60 mt-0.5">{sub}</p>}
    </div>
  );
}

// ─── Main Auditor Dashboard ───────────────────────────────────────────────────
export default function AuditorDashboard() {
  const { journalEntries } = useAppContext();
  const [activeTab, setActiveTab] = useState<Tab>('journal');
  const [searchJournal, setSearchJournal] = useState('');
  const [searchAudit, setSearchAudit] = useState('');

  // Computed totals
  const totalDebit = journalEntries.reduce((sum, j) => sum + j.amount, 0);
  const totalCredit = totalDebit; // Double-entry = always balanced

  const filteredJournals = journalEntries.filter(j =>
    !searchJournal ||
    j.transaction_ref.toLowerCase().includes(searchJournal.toLowerCase()) ||
    j.debit_account.toLowerCase().includes(searchJournal.toLowerCase()) ||
    j.credit_account.toLowerCase().includes(searchJournal.toLowerCase())
  );

  const filteredAudit = auditTrail.filter(a =>
    !searchAudit ||
    a.user_id.toLowerCase().includes(searchAudit.toLowerCase()) ||
    a.action.toLowerCase().includes(searchAudit.toLowerCase()) ||
    a.module.toLowerCase().includes(searchAudit.toLowerCase())
  );

  return (
    <div className="space-y-5">
      {/* ── Summary bar ── */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-3">
        <SummaryCard
          label="Total Entri Jurnal"
          value={journalEntries.length}
          sub="Double-entry entries"
          cls="bg-violet-600 text-white"
        />
        <SummaryCard
          label="Total Debit"
          value={`Rp ${totalDebit.toLocaleString('id-ID')}`}
          sub="Akun bertambah (D)"
          cls="bg-emerald-600 text-white"
        />
        <SummaryCard
          label="Total Kredit"
          value={`Rp ${totalCredit.toLocaleString('id-ID')}`}
          sub="Akun berkurang (K)"
          cls="bg-sky-600 text-white"
        />
        <SummaryCard
          label="Log Aktivitas"
          value={auditTrail.length}
          sub="Jejak audit sistem"
          cls="bg-slate-700 text-white"
        />
      </div>

      {/* ── Read-only notice ── */}
      <div className="flex items-center gap-2.5 bg-amber-50 border border-amber-200 rounded-xl px-4 py-3">
        <svg className="w-4 h-4 text-amber-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
        </svg>
        <p className="text-xs text-amber-700 font-medium">
          Mode <span className="font-bold">READ-ONLY</span> — Auditor tidak dapat mengubah data. Semua data bersumber dari sistem akuntansi.
        </p>
      </div>

      {/* ── Main panel ── */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
        {/* Tabs */}
        <div className="border-b border-slate-100 px-5 flex gap-1">
          <TabButton active={activeTab === 'journal'} onClick={() => setActiveTab('journal')}>
            Buku Jurnal Umum
            <span className="ml-2 text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded-full font-bold">
              {journalEntries.length}
            </span>
          </TabButton>
          <TabButton active={activeTab === 'audit'} onClick={() => setActiveTab('audit')}>
            Jejak Audit
            <span className="ml-2 text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded-full font-bold">
              {auditTrail.length}
            </span>
          </TabButton>
        </div>

        {/* ── Journal Tab ── */}
        {activeTab === 'journal' && (
          <div>
            {/* Search */}
            <div className="px-5 py-3 border-b border-slate-100">
              <div className="relative max-w-xs">
                <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                <input
                  type="text"
                  value={searchJournal}
                  onChange={e => setSearchJournal(e.target.value)}
                  placeholder="Cari referensi, akun..."
                  className="pl-9 pr-4 py-1.5 text-xs w-full bg-slate-50 border border-slate-200 rounded-xl text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-violet-400 focus:border-violet-300 transition-all"
                />
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-slate-50 text-xs text-slate-500 uppercase tracking-wider">
                    <th className="text-left px-5 py-3 font-medium">Journal ID</th>
                    <th className="text-left px-5 py-3 font-medium">Referensi</th>
                    <th className="text-left px-5 py-3 font-medium">Tanggal</th>
                    <th className="text-left px-5 py-3 font-medium">Akun Debit</th>
                    <th className="text-left px-5 py-3 font-medium">Akun Kredit</th>
                    <th className="text-right px-5 py-3 font-medium">Jumlah (Rp)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredJournals.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-5 py-10 text-center text-slate-400 text-sm">
                        Tidak ada data jurnal ditemukan
                      </td>
                    </tr>
                  ) : (
                    filteredJournals.map((j, idx) => (
                      <tr key={j.journal_id} className={`hover:bg-slate-50/70 transition-colors ${idx % 2 === 0 ? '' : 'bg-slate-50/30'}`}>
                        <td className="px-5 py-3 font-mono text-[11px] text-slate-400">{j.journal_id.substring(0, 16)}...</td>
                        <td className="px-5 py-3">
                          <span className="font-mono text-xs font-semibold text-violet-700">{j.transaction_ref}</span>
                        </td>
                        <td className="px-5 py-3 text-xs text-slate-500">
                          {new Date(j.entry_date).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' })}
                        </td>
                        <td className="px-5 py-3">
                          <span className="text-xs font-medium text-emerald-700 bg-emerald-50 border border-emerald-100 px-2 py-0.5 rounded-lg">
                            D: {j.debit_account}
                          </span>
                        </td>
                        <td className="px-5 py-3">
                          <span className="text-xs font-medium text-sky-700 bg-sky-50 border border-sky-100 px-2 py-0.5 rounded-lg">
                            K: {j.credit_account}
                          </span>
                        </td>
                        <td className="px-5 py-3 text-right font-mono text-sm font-bold text-slate-800">
                          {j.amount.toLocaleString('id-ID')}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
                {filteredJournals.length > 0 && (
                  <tfoot>
                    <tr className="bg-slate-50 border-t-2 border-slate-200">
                      <td colSpan={5} className="px-5 py-3 text-xs font-bold text-slate-500 uppercase">Total</td>
                      <td className="px-5 py-3 text-right font-mono font-bold text-slate-900">
                        {filteredJournals.reduce((s, j) => s + j.amount, 0).toLocaleString('id-ID')}
                      </td>
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>
          </div>
        )}

        {/* ── Audit Trail Tab ── */}
        {activeTab === 'audit' && (
          <div>
            {/* Search */}
            <div className="px-5 py-3 border-b border-slate-100">
              <div className="relative max-w-xs">
                <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                <input
                  type="text"
                  value={searchAudit}
                  onChange={e => setSearchAudit(e.target.value)}
                  placeholder="Cari user, aksi, modul..."
                  className="pl-9 pr-4 py-1.5 text-xs w-full bg-slate-50 border border-slate-200 rounded-xl text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-violet-400 focus:border-violet-300 transition-all"
                />
              </div>
            </div>

            {/* Audit list */}
            <div className="divide-y divide-slate-100">
              {filteredAudit.length === 0 ? (
                <div className="px-5 py-10 text-center text-slate-400 text-sm">
                  Tidak ada log aktivitas ditemukan
                </div>
              ) : (
                filteredAudit.map((a, idx) => (
                  <div key={a.audit_id} className={`px-5 py-3.5 flex items-start gap-4 hover:bg-slate-50/70 transition-colors ${idx % 2 === 0 ? '' : 'bg-slate-50/20'}`}>
                    {/* Timeline dot */}
                    <div className="flex flex-col items-center shrink-0 pt-0.5">
                      <div className="w-2 h-2 bg-violet-400 rounded-full" />
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0 flex items-center gap-3 flex-wrap">
                      <span className="text-[11px] text-slate-400 font-mono shrink-0">
                        {new Date(a.timestamp).toLocaleString('id-ID', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
                      </span>
                      <span className="text-xs font-bold text-slate-700 shrink-0">{a.user_id}</span>
                      <ActionBadge action={a.action} />
                      <span className="text-xs text-slate-500">
                        Modul: <span className="font-semibold text-slate-600">{a.module}</span>
                      </span>
                      {a.target_id && (
                        <span className="text-[11px] text-slate-400 font-mono bg-slate-100 px-2 py-0.5 rounded">
                          → {a.target_id}
                        </span>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}