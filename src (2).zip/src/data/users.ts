import { User } from '../types';

export const users: User[] = [
  {
    user_id: 'USR-00001',
    full_name: 'Sistem Cashier',
    username: 'Cashier',
    password: '1234',
    role: 'CASHIER',
    phone_number: '+62800-0000-0001',
    created_at: '2024-01-01T08:00:00Z',
    account_status: 'ACTIVE'
  },
  {
    user_id: 'USR-00009',
    full_name: 'Sistem Owner',
    username: 'Owner',
    password: '1234',
    role: 'OWNER',
    phone_number: '+62800-0000-0002',
    created_at: '2024-01-01T08:00:00Z',
    account_status: 'ACTIVE'
  },
  {
    user_id: 'USR-00012',
    full_name: 'Sistem Auditor',
    username: 'Auditor',
    password: '1234',
    role: 'AUDITOR',
    phone_number: '+62800-0000-0003',
    created_at: '2024-01-01T08:00:00Z',
    account_status: 'ACTIVE'
  },
];

// Helper functions
export const getUserById = (userId: string): User | undefined => {
  return users.find(user => user.user_id === userId);
};

export const getUsersByRole = (role: string): User[] => {
  return users.filter(user => user.role === role);
};

export const getActiveUsers = (): User[] => {
  return users.filter(user => user.account_status === 'ACTIVE');
};