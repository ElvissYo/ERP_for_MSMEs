import React, { useState } from 'react';
import { getActiveServices } from '../data/services';
import { Service } from '../data/index';
import { useAppContext } from '../context/AppContext';

// ─── Types ────────────────────────────────────────────────────────────────────
interface CheckoutResult {
  transactionId: string;
  subtotal: number;
  tax: number;
  total: number;
  entries: { account: string; debit: number; credit: number }[];
  itemsSummary: string;
  timestamp: string;
}

interface CartItem {
  service: Service;
  quantity: number;
}

// ─── Category badge color map ────────────────────────────────────────────────
const CATEGORY_COLORS: Record<string, string> = {
  Printing:   'bg-blue-50  text-blue-700  border border-blue-200',
  Fotocopy:   'bg-violet-50 text-violet-700 border border-violet-200',
  Binding:    'bg-amber-50  text-amber-700  border border-amber-200',
  Laminating: 'bg-emerald-50 text-emerald-700 border border-emerald-200',
  Scan:       'bg-sky-50    text-sky-700    border border-sky-200',
  default:    'bg-slate-100 text-slate-600  border border-slate-200',
};

function CategoryBadge({ category }: { category: string }) {
  const cls = CATEGORY_COLORS[category] || CATEGORY_COLORS.default;
  return (
    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${cls}`}>
      {category}
    </span>
  );
}

// ─── Success / Checkout Receipt ───────────────────────────────────────────────
function CheckoutSuccessScreen({ result, onBack }: { result: CheckoutResult; onBack: () => void }) {
  return (
    <div className="max-w-2xl mx-auto space-y-4">
      {/* Success header */}
      <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-6 flex items-start gap-4">
        <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center shrink-0">
          <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <div>
          <h2 className="text-lg font-bold text-emerald-800">Pembayaran Berhasil</h2>
          <p className="text-emerald-700 text-sm mt-0.5">
            ID Transaksi: <span className="font-mono font-bold">{result.transactionId}</span>
          </p>
          <p className="text-emerald-600 text-xs mt-1">{result.timestamp} · {result.itemsSummary}</p>
        </div>
        <div className="ml-auto text-right">
          <p className="text-xs text-emerald-600 mb-0.5">Total Diterima</p>
          <p className="text-2xl font-bold text-emerald-800">Rp {result.total.toLocaleString('id-ID')}</p>
        </div>
      </div>

      {/* Summary row */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Subtotal', val: result.subtotal },
          { label: 'PPN 11%', val: result.tax },
          { label: 'Grand Total', val: result.total },
        ].map(item => (
          <div key={item.label} className="bg-white border border-slate-200 rounded-xl p-4">
            <p className="text-xs text-slate-500 mb-1">{item.label}</p>
            <p className="text-base font-bold text-slate-800">Rp {item.val.toLocaleString('id-ID')}</p>
          </div>
        ))}
      </div>

      {/* Journal entries */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center gap-2">
          <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          <h3 className="text-sm font-semibold text-slate-700">Penjurnalan Otomatis — Double Entry</h3>
          <span className="ml-auto text-[10px] bg-violet-100 text-violet-700 border border-violet-200 px-2 py-0.5 rounded-full font-semibold">SYSTEM</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 text-xs text-slate-500 uppercase tracking-wider">
                <th className="text-left px-5 py-3 font-medium">Nama Akun</th>
                <th className="text-right px-5 py-3 font-medium">Debit (Rp)</th>
                <th className="text-right px-5 py-3 font-medium">Kredit (Rp)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {result.entries.map((entry, idx) => (
                <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-5 py-3 font-medium text-slate-700">{entry.account}</td>
                  <td className="px-5 py-3 text-right font-mono text-emerald-700">
                    {entry.debit > 0 ? `Rp ${entry.debit.toLocaleString('id-ID')}` : <span className="text-slate-300">—</span>}
                  </td>
                  <td className="px-5 py-3 text-right font-mono text-sky-700">
                    {entry.credit > 0 ? `Rp ${entry.credit.toLocaleString('id-ID')}` : <span className="text-slate-300">—</span>}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-slate-50 border-t-2 border-slate-200">
                <td className="px-5 py-3 text-xs font-bold text-slate-500 uppercase">Balance Jurnal</td>
                <td className="px-5 py-3 text-right font-bold font-mono text-slate-800">Rp {result.total.toLocaleString('id-ID')}</td>
                <td className="px-5 py-3 text-right font-bold font-mono text-slate-800">Rp {result.total.toLocaleString('id-ID')}</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      <button
        onClick={onBack}
        className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-xl text-sm transition-all duration-150 flex items-center justify-center gap-2"
      >
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
        </svg>
        Kembali ke Terminal Kasir
      </button>
    </div>
  );
}

// ─── Main Cashier Dashboard ───────────────────────────────────────────────────
export default function CashierDashboard() {
  const activeServices = getActiveServices();
  const [cart, setCart] = useState<CartItem[]>([]);
  const [checkoutResult, setCheckoutResult] = useState<CheckoutResult | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('Semua');
  const { addTransaction, addJournalEntries, deductInventory } = useAppContext();

  const categories = ['Semua', ...Array.from(new Set(activeServices.map(s => s.category)))];

  const filteredServices = activeCategory === 'Semua'
    ? activeServices
    : activeServices.filter(s => s.category === activeCategory);

  const addToCart = (service: Service) => {
    setCart(prev => {
      const existing = prev.find(item => item.service.service_id === service.service_id);
      if (existing) {
        return prev.map(item => item.service.service_id === service.service_id
          ? { ...item, quantity: item.quantity + 1 }
          : item
        );
      }
      return [...prev, { service, quantity: 1 }];
    });
  };

  const decreaseQty = (serviceId: string) => {
    setCart(prev =>
      prev
        .map(item => item.service.service_id === serviceId
          ? { ...item, quantity: item.quantity - 1 }
          : item
        )
        .filter(item => item.quantity > 0)
    );
  };

  const removeFromCart = (serviceId: string) => {
    setCart(prev => prev.filter(item => item.service.service_id !== serviceId));
  };

  const subtotal = cart.reduce((sum, item) => sum + item.service.unit_price * item.quantity, 0);
  const tax = subtotal * 0.11;
  const total = subtotal + tax;
  const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const handleCheckout = () => {
    const txnId = `TXN-NEW-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`;
    const now = new Date();

    addTransaction({
      transaction_id: txnId,
      cashier_id: 'USR-00001',
      service_id: cart[0]?.service.service_id || 'MULTI-SRV',
      quantity: 1,
      subtotal,
      tax_amount: tax,
      total_amount: total,
      payment_method: 'CASH',
      payment_status: 'PAID',
      transaction_date: now.toISOString(),
    });

    addJournalEntries([
      {
        journal_id: `JRN-${Date.now()}-1`,
        transaction_ref: txnId,
        debit_account: '1010 - Cash',
        credit_account: '4010 - Service Revenue',
        amount: subtotal,
        created_by: 'SYSTEM',
        entry_date: now.toISOString(),
      },
      {
        journal_id: `JRN-${Date.now()}-2`,
        transaction_ref: txnId,
        debit_account: '1010 - Cash',
        credit_account: '2010 - Tax Payable (PPN)',
        amount: tax,
        created_by: 'SYSTEM',
        entry_date: now.toISOString(),
      },
    ]);

    let totalPaperUsed = 0;
    cart.forEach(item => {
      if (item.service.category === 'Printing') totalPaperUsed += item.quantity;
    });
    if (totalPaperUsed > 0) deductInventory('INV-00001', totalPaperUsed);

    const itemsSummary = cart.map(c => `${c.service.service_name} ×${c.quantity}`).join(', ');

    setCheckoutResult({
      transactionId: txnId,
      subtotal,
      tax,
      total,
      itemsSummary,
      timestamp: now.toLocaleString('id-ID'),
      entries: [
        { account: '1010 - Cash', debit: total, credit: 0 },
        { account: '4010 - Service Revenue', debit: 0, credit: subtotal },
        { account: '2010 - Tax Payable (PPN)', debit: 0, credit: tax },
      ],
    });
    setCart([]);
  };

  if (checkoutResult) {
    return <CheckoutSuccessScreen result={checkoutResult} onBack={() => setCheckoutResult(null)} />;
  }

  return (
    <div className="flex gap-5 h-full min-h-0">
      {/* ── Left: Product catalog ── */}
      <div className="flex-1 flex flex-col gap-4 min-w-0">
        {/* Category filter */}
        <div className="flex gap-2 flex-wrap">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all duration-150 ${
                activeCategory === cat
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'bg-white border border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-slate-50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Service grid */}
        <div className="grid grid-cols-2 xl:grid-cols-3 gap-3 overflow-y-auto pb-2 pr-1">
          {filteredServices.map(service => (
            <button
              key={service.service_id}
              onClick={() => addToCart(service)}
              className="bg-white border border-slate-200 rounded-xl p-4 text-left hover:border-violet-300 hover:shadow-sm transition-all duration-150 group"
            >
              <div className="flex items-start justify-between mb-2">
                <CategoryBadge category={service.category} />
                <div className="w-7 h-7 rounded-lg bg-slate-100 group-hover:bg-violet-100 flex items-center justify-center transition-colors">
                  <svg className="w-3.5 h-3.5 text-slate-400 group-hover:text-violet-600 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                  </svg>
                </div>
              </div>
              <p className="text-sm font-semibold text-slate-800 mt-2 leading-snug">{service.service_name}</p>
              <p className="text-base font-bold text-violet-700 mt-1.5">
                Rp {service.unit_price.toLocaleString('id-ID')}
                <span className="text-xs font-normal text-slate-400"> / unit</span>
              </p>
            </button>
          ))}
        </div>
      </div>

      {/* ── Right: Cart ── */}
      <div className="w-72 shrink-0 flex flex-col bg-white border border-slate-200 rounded-2xl overflow-hidden">
        {/* Cart header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
            <h3 className="text-sm font-semibold text-slate-700">Keranjang</h3>
          </div>
          {itemCount > 0 && (
            <span className="bg-violet-600 text-white text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">
              {itemCount}
            </span>
          )}
        </div>

        {/* Cart items */}
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-2">
          {cart.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full py-10 text-center">
              <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mb-3">
                <svg className="w-6 h-6 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </div>
              <p className="text-sm text-slate-400 font-medium">Keranjang kosong</p>
              <p className="text-xs text-slate-300 mt-1">Pilih layanan dari katalog</p>
            </div>
          ) : (
            cart.map(item => (
              <div key={item.service.service_id} className="bg-slate-50 rounded-xl p-3">
                <div className="flex items-start justify-between gap-2">
                  <p className="text-xs font-semibold text-slate-700 flex-1 leading-snug">{item.service.service_name}</p>
                  <button
                    onClick={() => removeFromCart(item.service.service_id)}
                    className="text-slate-300 hover:text-red-400 transition-colors shrink-0 mt-0.5"
                  >
                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
                <div className="flex items-center justify-between mt-2">
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => decreaseQty(item.service.service_id)}
                      className="w-5 h-5 rounded-md bg-white border border-slate-200 flex items-center justify-center text-slate-500 hover:bg-slate-100 text-xs font-bold transition-colors"
                    >−</button>
                    <span className="text-xs font-bold text-slate-700 w-4 text-center">{item.quantity}</span>
                    <button
                      onClick={() => addToCart(item.service)}
                      className="w-5 h-5 rounded-md bg-white border border-slate-200 flex items-center justify-center text-slate-500 hover:bg-slate-100 text-xs font-bold transition-colors"
                    >+</button>
                  </div>
                  <p className="text-xs font-bold text-violet-700">
                    Rp {(item.service.unit_price * item.quantity).toLocaleString('id-ID')}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Cart footer */}
        {cart.length > 0 && (
          <div className="border-t border-slate-100 px-5 py-4 space-y-2.5">
            <div className="flex justify-between text-xs text-slate-500">
              <span>Subtotal</span>
              <span className="font-medium text-slate-700">Rp {subtotal.toLocaleString('id-ID')}</span>
            </div>
            <div className="flex justify-between text-xs text-slate-500">
              <span>PPN 11%</span>
              <span className="font-medium text-slate-700">Rp {tax.toLocaleString('id-ID')}</span>
            </div>
            <div className="flex justify-between text-sm font-bold text-slate-900 pt-1.5 border-t border-slate-100">
              <span>Total</span>
              <span className="text-violet-700">Rp {total.toLocaleString('id-ID')}</span>
            </div>
            <button
              onClick={handleCheckout}
              className="w-full mt-1 py-2.5 bg-violet-600 hover:bg-violet-700 text-white text-sm font-bold rounded-xl transition-all duration-150 shadow-sm shadow-violet-200 flex items-center justify-center gap-2"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
              Proses Pembayaran
            </button>
          </div>
        )}
      </div>
    </div>
  );
}